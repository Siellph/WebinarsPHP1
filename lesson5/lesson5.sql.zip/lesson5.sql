-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Мар 31 2020 г., 17:08
-- Версия сервера: 10.3.13-MariaDB-log
-- Версия PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `lesson5`
--

-- --------------------------------------------------------

--
-- Структура таблицы `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `filename` varchar(10) NOT NULL,
  `type` varchar(5) NOT NULL,
  `path-small` varchar(50) NOT NULL,
  `path-big` varchar(50) NOT NULL,
  `opened` int(11) DEFAULT NULL,
  `seen` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `gallery`
--

INSERT INTO `gallery` (`id`, `filename`, `type`, `path-small`, `path-big`, `opened`, `seen`) VALUES
(1, '1.jpg', 'jpg', 'public/pictures/small/1.jpg', 'public/pictures/big/1.jpg', NULL, NULL),
(2, '2.jpg', 'jpg', 'public/pictures/small/2.jpg', 'public/pictures/big/2.jpg', NULL, NULL),
(3, '3.jpg', 'jpg', 'public/pictures/small/3.jpg', 'public/pictures/big/3.jpg', NULL, NULL),
(4, '4.jpg', 'jpg', 'public/pictures/small/4.jpg', 'public/pictures/big/4.jpg', NULL, NULL),
(5, '5.jpg', 'jpg', 'public/pictures/small/5.jpg', 'public/pictures/big/5.jpg', NULL, NULL),
(6, '6.jpg', 'jpg', 'public/pictures/small/6.jpg', 'public/pictures/big/6.jpg', NULL, NULL),
(7, '7.jpg', 'jpg', 'public/pictures/small/7.jpg', 'public/pictures/big/7.jpg', NULL, NULL),
(8, '8.jpg', 'jpg', 'public/pictures/small/8.jpg', 'public/pictures/big/8.jpg', NULL, NULL),
(9, '9.jpg', 'jpg', 'public/pictures/small/9.jpg', 'public/pictures/big/9.jpg', NULL, NULL),
(10, '10.jpg', 'jpg', 'public/pictures/small/10.jpg', 'public/pictures/big/10.jpg', NULL, NULL),
(11, '11.jpg', 'jpg', 'public/pictures/small/11.jpg', 'public/pictures/big/11.jpg', NULL, NULL),
(12, '12.jpg', 'jpg', 'public/pictures/small/12.jpg', 'public/pictures/big/12.jpg', NULL, NULL),
(13, '13.jpg', 'jpg', 'public/pictures/small/13.jpg', 'public/pictures/big/13.jpg', NULL, NULL),
(14, '14.jpg', 'jpg', 'public/pictures/small/14.jpg', 'public/pictures/big/14.jpg', NULL, NULL),
(15, '15.jpg', 'jpg', 'public/pictures/small/15.jpg', 'public/pictures/big/15.jpg', NULL, NULL),
(16, '16.jpg', 'jpg', 'public/pictures/small/16.jpg', 'public/pictures/big/16.jpg', NULL, NULL),
(17, '17.jpg', 'jpg', 'public/pictures/small/17.jpg', 'public/pictures/big/17.jpg', NULL, NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
